import vaporm.V2VMLauncher


object V2VM {

  def main(args: Array[String]) {
    V2VMLauncher.main(args)
  }

}