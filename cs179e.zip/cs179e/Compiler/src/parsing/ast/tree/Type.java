package parsing.ast.tree;

/**
 * User: Mohsen's Desktop
 * Date: Aug 26, 2009
 */

public interface Type extends Node {
}
