import awkparse.Parser


object Parse {
  def main(args: Array[String]) {
    Parser.main(args)
  }
}

