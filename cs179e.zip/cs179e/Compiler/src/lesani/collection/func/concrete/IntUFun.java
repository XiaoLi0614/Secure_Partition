package lesani.collection.func.concrete;

import lesani.collection.func.Fun;

/**
 * Created by IntelliJ IDEA.
 * User: mohsen
 * Date: Feb 27, 2010
 * Time: 1:51:04 AM
 */

public abstract class IntUFun implements Fun<Integer, Integer> {}