package lesani.collection.func.concrete;

import lesani.collection.func.Fun2;

/**
 * Created by IntelliJ IDEA.
 * User: mohsen
 * Date: Feb 27, 2010
 * Time: 1:51:04 AM
 */

public abstract class IntBFun implements Fun2<Integer, Integer, Integer> {}

