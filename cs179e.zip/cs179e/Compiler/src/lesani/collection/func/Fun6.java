package lesani.collection.func;

/**
 * Created by IntelliJ IDEA.
 * User: mohsen
 * Date: Feb 27, 2010
 * Time: 1:43:52 AM
 */

public interface Fun6<T1, T2, T3, T4, T5, T6, T7> {
    public T7 apply(T1 p1, T2 p2, T3 p3, T4 p4, T5 p5, T6 p6);
}

