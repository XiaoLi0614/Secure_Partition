package lesani.collection.func;

/**
 * Created by IntelliJ IDEA.
 * User: mohsen
 * Date: Feb 27, 2010
 * Time: 1:43:52 AM
 */

public interface Fun3<T1, T2, T3, T4> {
    public T4 apply(T1 p1, T2 p2, T3 p3);
}

