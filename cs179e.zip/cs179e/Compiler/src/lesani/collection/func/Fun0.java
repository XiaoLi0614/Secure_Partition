package lesani.collection.func;

/**
 * Created by IntelliJ IDEA.
 * User: mohsen
 * Date: Feb 27, 2010
 * Time: 1:43:52 AM
 */

public interface Fun0<T1> {
    public abstract T1 apply();
}