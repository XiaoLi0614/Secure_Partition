#!/bin/sh
./generate.sh
./compile.sh
