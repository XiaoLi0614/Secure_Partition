package lesani.alg.graph.scc;

public interface Node {
}
