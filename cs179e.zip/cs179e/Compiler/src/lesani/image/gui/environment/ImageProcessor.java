package lesani.image.gui.environment;

import lesani.image.core.image.GSImage;

/**
* Created by IntelliJ IDEA.
* User: lesani
* Date: Mar 15, 2010
* Time: 3:39:13 PM
*/


public interface ImageProcessor {
    public abstract GSImage process(GSImage image);
}
