package lesani.image.xdatahiding.runlength.core;

/**
 * Created by IntelliJ IDEA.
 * User: Mohsen Lesani
 * Date: Jun 11, 2005
 * Time: 11:36:19 AM
 */
public class NoMoreRunPairException extends Exception
{
	public NoMoreRunPairException(String s)
	{
		super(s);
	}
}
