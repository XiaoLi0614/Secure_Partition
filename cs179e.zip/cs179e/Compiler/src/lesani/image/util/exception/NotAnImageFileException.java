package lesani.image.util.exception;

/**
 * Created by IntelliJ IDEA.
 * User: Mohsen Lesani
 * Date: Apr 14, 2005
 * Time: 3:12:19 PM
 */
public class NotAnImageFileException extends Exception
{
}
