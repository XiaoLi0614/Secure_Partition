package lesani.image.registration;

import lesani.collection.func.Fun;
import lesani.collection.vector.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: mohsen
 * Date: May 23, 2010
 * Time: 4:27:09 PM
 */
public abstract class Transformer implements Fun<Vector, Vector> {
}
