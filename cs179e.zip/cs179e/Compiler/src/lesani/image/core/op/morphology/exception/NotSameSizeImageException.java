package lesani.image.core.op.morphology.exception;

/**
 * Created by IntelliJ IDEA.
 * User: Mohsen Lesani
 * Date: Apr 15, 2005
 * Time: 4:15:30 PM
 */
public class NotSameSizeImageException extends RuntimeException
{
}
