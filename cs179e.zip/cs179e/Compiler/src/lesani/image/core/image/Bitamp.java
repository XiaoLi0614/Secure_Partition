package lesani.image.core.image;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: May 25, 2010
 * Time: 3:13:16 PM
 */
public class Bitamp {
}
