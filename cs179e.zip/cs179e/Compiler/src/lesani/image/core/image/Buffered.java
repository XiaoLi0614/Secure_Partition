package lesani.image.core.image;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: May 25, 2010
 * Time: 3:13:08 PM
 */
public class Buffered {

//    public static convertTo
}
