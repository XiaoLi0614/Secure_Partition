package lesani.compiler.typing.exception;

/**
 * User: Mohsen's Desktop
 * Date: Aug 30, 2009
 */

public class InternalTypingException extends Exception {
	public InternalTypingException(String message) {
		super(message);
	}
}
