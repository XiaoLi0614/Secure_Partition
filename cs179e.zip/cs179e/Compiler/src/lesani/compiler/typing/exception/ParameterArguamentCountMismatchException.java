package lesani.compiler.typing.exception;

public class ParameterArguamentCountMismatchException extends TypeErrorException {
    public ParameterArguamentCountMismatchException(String message) {
        super(message);
    }
}
