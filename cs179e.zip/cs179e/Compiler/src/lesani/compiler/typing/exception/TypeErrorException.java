package lesani.compiler.typing.exception;

/**
 * User: Mohsen's Desktop
 * Date: Aug 28, 2009
 */

public class TypeErrorException extends RuntimeException {
	public TypeErrorException(String message) {
		super(message);
	}
}
