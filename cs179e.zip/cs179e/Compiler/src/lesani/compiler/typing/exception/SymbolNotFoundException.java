package lesani.compiler.typing.exception;


/**
 * User: Mohsen's Desktop
 * Date: Aug 26, 2009
 */

public class SymbolNotFoundException extends InternalTypingException {
	public SymbolNotFoundException(String s) {
		super(s);
	}
}
