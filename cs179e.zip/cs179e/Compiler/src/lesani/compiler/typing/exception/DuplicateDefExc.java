package lesani.compiler.typing.exception;


/**
 * User: Mohsen's Desktop
 * Date: Aug 26, 2009
 */

public class DuplicateDefExc extends InternalTypingException {
	public DuplicateDefExc(String message) {
		super(message);
	}
}
