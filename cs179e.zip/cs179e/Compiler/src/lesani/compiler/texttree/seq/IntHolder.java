package lesani.compiler.texttree.seq;

class IntHolder {
    int i;

    IntHolder(int i) {
        this.i = i;
    }
}
