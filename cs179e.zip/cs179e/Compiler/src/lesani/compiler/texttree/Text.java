package lesani.compiler.texttree;

/**
 * User: lesani, Date: 9-Nov-2009, Time: 7:46:20 PM
 */
public abstract class Text implements Printable {
    public abstract String print();
}
