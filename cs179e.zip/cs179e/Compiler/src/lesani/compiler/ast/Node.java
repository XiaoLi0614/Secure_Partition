package lesani.compiler.ast;

public interface Node {
//    int lineNo;
//    int columnNo;
//    int getLineNo();
//    int setLineNo(int no);
//    int getColumnNo();
//    int setColumnNo(int no);
}

// This is the node that the ASTBuilder works on.
// There are nodes that ASTBuilder works on but Translator does not.
// Translator works on ast.tree.Node that
// is a sub-interface of this interface.


