package lesani.compiler.constraintsolver;

public interface Constraint<Var> {
}
