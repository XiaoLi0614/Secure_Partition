package lesani.file.xtras;

import lesani.file.Address;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Mar 2, 2010
 * Time: 2:10:13 PM
 */

public class AbsoluteAddress extends Address {
    public AbsoluteAddress(String value) {
        super(value);
    }
}
