package lesani.file.xtras;

import lesani.file.Address;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Mar 2, 2010
 * Time: 2:08:51 PM
 */


public class RelativeAddress extends Address {
    public RelativeAddress(String value) {
        super(value);
    }
}
