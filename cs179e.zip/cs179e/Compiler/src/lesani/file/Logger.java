package lesani.file;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Nov 1, 2010
 * Time: 5:16:43 PM
 */

public abstract class Logger {
    public Logger test;
    public abstract void print(String s);
    public abstract void println(String s);
    public abstract void startLine(String s);
    public abstract void endLine(String s);
}


