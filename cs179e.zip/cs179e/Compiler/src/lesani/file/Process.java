package lesani.file;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Mar 2, 2010
 * Time: 1:39:54 PM
 */

public interface Process {}
