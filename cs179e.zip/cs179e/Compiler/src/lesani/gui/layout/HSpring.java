package lesani.gui.layout;

import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: Mohsen's Desktop
 * Date: Apr 16, 2008
 * Time: 12:45:50 AM
 */
public class HSpring extends javax.swing.Box.Filler
{
	public HSpring()
	{
		super(new Dimension(0,0), new Dimension(0,0), new Dimension(Short.MAX_VALUE, 0));
    }

}

