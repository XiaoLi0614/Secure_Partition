package typechecking.types;

/**
 * User: Mohsen's Desktop
 * Date: Aug 25, 2009
 */
public interface Type {
	String name();
}
