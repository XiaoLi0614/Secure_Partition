package awkparse.parser.ast

class PreMinusMinus(op: Exp) extends UOp(op, "--_")

