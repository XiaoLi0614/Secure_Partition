package awkparse.parser.ast

class PostMinusMinus(val op: Exp) extends UOp(op, "_--")

