package awkparse.parser.ast

class Field(op: Exp) extends UOp(op, "$")


