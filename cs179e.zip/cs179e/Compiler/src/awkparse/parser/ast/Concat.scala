package awkparse.parser.ast

class Concat(op1: Exp, op2: Exp) extends BinOp(op1, op2, "_")

