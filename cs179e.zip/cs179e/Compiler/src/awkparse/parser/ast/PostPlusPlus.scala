package awkparse.parser.ast

class PostPlusPlus(op: Exp) extends UOp(op, "_++")

