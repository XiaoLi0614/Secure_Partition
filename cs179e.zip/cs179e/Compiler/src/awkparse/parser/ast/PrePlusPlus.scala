package awkparse.parser.ast

class PrePlusPlus(op: Exp) extends UOp(op, "++_")

