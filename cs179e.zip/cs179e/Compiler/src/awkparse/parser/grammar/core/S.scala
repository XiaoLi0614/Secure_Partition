package awkparse.parser.grammar.core


object S extends NonTerminal("S")