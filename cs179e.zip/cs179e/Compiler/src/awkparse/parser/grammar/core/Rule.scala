package awkparse.parser.grammar.core


case class Rule(lhs: NonTerminal, rhs: Array[Symbol])

