package awkparse.parser.grammar.core

class Symbol {}