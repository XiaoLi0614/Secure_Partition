package awkparse.parser.grammar.awk

import awkparse.parser.grammar.core.NonTerminal


object FE extends NonTerminal("FE")