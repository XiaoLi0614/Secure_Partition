package awkparse.parser.grammar.awk

import awkparse.parser.grammar.core.NonTerminal


object N extends NonTerminal("N")