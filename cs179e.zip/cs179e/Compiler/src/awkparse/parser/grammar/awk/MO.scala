package awkparse.parser.grammar.awk

import awkparse.parser.grammar.core.NonTerminal


object MO extends NonTerminal("MO")