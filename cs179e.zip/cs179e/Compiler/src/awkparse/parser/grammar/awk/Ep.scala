package awkparse.parser.grammar.awk

import awkparse.parser.grammar.core.NonTerminal


object Ep extends NonTerminal("E\'")