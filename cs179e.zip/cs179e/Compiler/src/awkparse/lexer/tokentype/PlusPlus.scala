package awkparse.lexer.tokentype

object PlusPlus extends TokenType("\"++\"")



