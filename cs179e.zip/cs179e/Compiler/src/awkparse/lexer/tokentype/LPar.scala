package awkparse.lexer.tokentype

object LPar extends TokenType("\"(\"")







