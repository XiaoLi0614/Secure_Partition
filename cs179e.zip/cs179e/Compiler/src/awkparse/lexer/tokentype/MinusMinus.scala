package awkparse.lexer.tokentype

object MinusMinus extends TokenType("\"--\"")


