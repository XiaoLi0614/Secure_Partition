package awkparse.lexer.tokentype

object Num extends TokenType("Num")








