package awkparse.lexer.tokentype

object Dollar extends TokenType("\"$\"")

