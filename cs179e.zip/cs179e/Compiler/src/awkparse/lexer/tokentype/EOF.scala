package awkparse.lexer.tokentype

object EOF extends TokenType("EOF")
