package awkparse.lexer.tokentype

object RPar extends TokenType("\")\"")






