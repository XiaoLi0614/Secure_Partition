package awkparse.lexer.tokentype

object Minus extends TokenType("\"-\"")




