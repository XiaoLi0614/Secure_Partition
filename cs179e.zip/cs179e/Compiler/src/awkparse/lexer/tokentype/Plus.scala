package awkparse.lexer.tokentype

object Plus extends TokenType("\"+\"")





