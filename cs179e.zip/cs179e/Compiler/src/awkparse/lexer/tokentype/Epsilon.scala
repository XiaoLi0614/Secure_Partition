package awkparse.lexer.tokentype

object Epsilon extends TokenType("Epsilon")

