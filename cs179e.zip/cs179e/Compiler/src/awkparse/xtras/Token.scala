

/*
class Token extends TokenTypes {

  private var `type` : Int = 0
  private var text: String = null
  private var lineNo: Int = 0
  private var columnNo: Int = 0

  def this(t: Int) {
    this ()
    `type` = t
  }

  def this(t: Int, txt: String) {
    this ()
    `type` = t
    setText(txt)
  }


  def setType(t: Int) {
    `type` = t
  }

  def setText(text: String) {
    this.text = text
  }

  def setLocation(lineNo: Int, columnNo: Int) {
    this.lineNo = lineNo
    this.columnNo = columnNo
  }

  def setLineNo(lineNo: Int) {
    this.lineNo = lineNo
  }

  def setColumnNo(columnNo: Int) {
    this.columnNo = columnNo
  }

  override def toString: String = {
    if (`type` == EOF) return getTypeName
    getText + " : " + getTypeName
  }

}

*/



