import vapor.J2VLauncher


object J2V {

  def main(args: Array[String]) {
    J2VLauncher.main(args);
  }

}