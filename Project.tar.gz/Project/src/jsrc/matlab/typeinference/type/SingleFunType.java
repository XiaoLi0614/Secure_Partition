package jsrc.matlab.typeinference.type;

public interface SingleFunType extends FunType {
}
