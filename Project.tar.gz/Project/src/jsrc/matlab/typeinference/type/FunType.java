package jsrc.matlab.typeinference.type;

public interface FunType extends Type {
}
