package jsrc.matlab.typeinference.exceptions;

public class NonScalarElementException extends RuntimeException {
}
