package jsrc.matlab.typeinference.constraintelicitation;

public class Value {
    Object object;

    public Value(Object object) {
        this.object = object;
    }
}
