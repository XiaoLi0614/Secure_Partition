package jsrc.px10.astbuild.intastnodes.statement.caseparts;

import lesani.compiler.ast.Node;

/**
 * User: lesani, Date: Nov 3, 2009, Time: 11:43:29 AM
 */
public abstract class SwitchGuard implements Node {
}
