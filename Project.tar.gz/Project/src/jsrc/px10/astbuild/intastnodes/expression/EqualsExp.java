package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class EqualsExp extends EqualityExp {
    public EqualsExp(Expression e) {
        super(e);
    }
}
