package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class GreaterThanEqualExp extends RelExp {
    public GreaterThanEqualExp(Expression e) {
        super(e);
    }
}