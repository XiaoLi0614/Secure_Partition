package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class TimesExp extends MultiplicativeExp {
    public TimesExp(Expression e) {
        super(e);
    }
}
