package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class DivideExp extends MultiplicativeExp {
    public DivideExp(Expression e) {
        super(e);
    }
}