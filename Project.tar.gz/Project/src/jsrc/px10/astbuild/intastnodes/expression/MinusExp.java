package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class MinusExp extends AdditiveExp {
    public MinusExp(Expression e) {
        super(e);
    }
}