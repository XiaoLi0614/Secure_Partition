package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;

public class ShiftLeftExp extends ShiftExp {
    public ShiftLeftExp(Expression e) {
        super(e);
    }
}
