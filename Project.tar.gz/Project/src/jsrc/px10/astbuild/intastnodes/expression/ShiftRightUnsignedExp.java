package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;

public class ShiftRightUnsignedExp extends ShiftExp {
    public ShiftRightUnsignedExp(Expression e) {
        super(e);
    }
}