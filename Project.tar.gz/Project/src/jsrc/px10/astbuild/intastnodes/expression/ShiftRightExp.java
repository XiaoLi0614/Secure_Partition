package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;

public class ShiftRightExp extends ShiftExp {
    public ShiftRightExp(Expression e) {
        super(e);
    }
}