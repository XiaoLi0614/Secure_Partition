package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class PlusExp extends AdditiveExp {
    public PlusExp(Expression e) {
        super(e);
    }
}