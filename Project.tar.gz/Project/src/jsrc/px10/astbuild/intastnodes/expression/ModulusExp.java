package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class ModulusExp extends MultiplicativeExp {
    public ModulusExp(Expression e) {
        super(e);
    }
}