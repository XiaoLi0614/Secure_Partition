package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class LessThanExp extends RelExp {
    public LessThanExp(Expression e) {
        super(e);
    }
}
