package jsrc.px10.astbuild.intastnodes.expression;

import jsrc.x10.ast.tree.expression.Expression;


public class NotEqualsExp extends EqualityExp {
    public NotEqualsExp(Expression e) {
        super(e);
    }
}