a = twotimes(2);
b = twotimes(2.1);
c = recEven(4);
if (b > 2)
    y = a + c;
else
    y = a;
end
y