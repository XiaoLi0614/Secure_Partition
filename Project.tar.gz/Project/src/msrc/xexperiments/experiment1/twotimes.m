function y = twotimes(x)
	y = 2 * x;
	
	