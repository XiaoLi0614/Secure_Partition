function y = recOdd(x)
	if (x == 1)
		y = 1;
	else
		y = recEven(x - 1);
    end

		
