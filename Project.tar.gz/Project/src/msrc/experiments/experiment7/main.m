n = 5;
y = zeros(n, 1);
y = randn(size(y));
disp(y);