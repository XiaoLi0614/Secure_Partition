function check(asser)
    if (asser)
        disp('Passed');
    else
        disp('Failed');
    end
    disp(' ')