function m = maxFun(x, y)
   if (x >= y)
      m = x;
   else
      m = y;
   end
