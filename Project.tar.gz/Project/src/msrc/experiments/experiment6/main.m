% tests a function without parameters and vector concat

a = f();
disp(a);

m1 = [1 2 3];
m2 = [4 5 6];
m3 = [0, m1];
disp(m3);
m4 = [m1, 4];
disp(m4);
m5 = [m1, m2];
disp(m5);


