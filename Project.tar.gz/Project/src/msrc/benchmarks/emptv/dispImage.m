function dispImage(image)
    axis image
    axis off
    colormap(gray(256));
    imagesc(image);
%    drawnow;
%    shg;

