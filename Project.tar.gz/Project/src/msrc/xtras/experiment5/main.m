
m1 = [1 2 3,
      4 5 6,
      7 8 9];
m2 = [1 2 3,
      4 5 6,
      7 8 9];


a1 = (m1 == m2)

%b1 = logical(1)
%b2 = (1 == 1)
%
%for i = 1:3
%    b1 = b1 && a1(1,1)
%end

%a = logical(1)

%b = a1(1, 1)
%c = b && b


b1 = fun(a1)

