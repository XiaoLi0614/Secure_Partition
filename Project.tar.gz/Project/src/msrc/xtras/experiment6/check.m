function check(asser)
    if (asser)
        println('Passed')
    else
        println('Failed')
    end
    println('')