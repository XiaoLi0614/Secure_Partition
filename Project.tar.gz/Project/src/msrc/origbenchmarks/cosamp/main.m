

result = CoSaMPFun();
result




