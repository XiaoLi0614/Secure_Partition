#include <Reducer.h>

x10aux::RuntimeType Reducer<void, void>::rtt;

