#include <Mapper.h>

x10aux::RuntimeType Mapper<void, void, void>::rtt;

