#include <MapReduceLauncher__HashSet.h>

x10aux::RuntimeType MapReduceLauncher__HashSet<void>::rtt;


extern "C" { const char* LNMAP__MapReduceLauncher__HashSet_h = "N{\"MapReduceLauncher__HashSet.h\"} F{0:\"/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translatedbenchs/hand/mapreduce/generic/MapReduceLauncher.x10\",1:\"MapReduceLauncher$HashSet\",2:\"iterator\",3:\"x10.lang.Iterator[T]\",4:\"MapReduceLauncher__HashSet<FMGL(T)>\",5:\"x10aux::ref<x10::lang::Iterator<FMGL(T)> >\",6:\"this\",7:\"\",8:\"_constructor\",9:\"void\",} L{20->0:191,24->0:192,26->0:193,29->0:190,} M{5 4.2()->3 1.2();9 4.8()->7 1.6();}"; }
