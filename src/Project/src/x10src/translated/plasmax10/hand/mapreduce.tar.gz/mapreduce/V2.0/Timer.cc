#include <Timer.h>


#include "Timer.inc"

void Timer::_instance_init() {
    _I_("Doing initialisation for class: Timer");
    
}


//#line 3 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10_int Timer::FMGL(max_counters) = ((x10_int)64);


//#line 4 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10aux::ref<x10::lang::Dist> Timer::FMGL(d);
void Timer::FMGL(d__do_init)() {
    FMGL(d__status) = x10aux::INITIALIZING;
    _I_("Doing static initialisation for field: Timer.d");
    x10aux::ref<x10::lang::Dist> __var0__ = x10::lang::Dist::makeConstant(
                                              x10::lang::Region::__implicit_convert(
                                                (x10aux::ref<x10::lang::ValRail<x10aux::ref<x10::lang::Region> > >)x10aux::alloc_rail<x10aux::ref<x10::lang::Region>,
                                                x10::lang::ValRail<x10aux::ref<x10::lang::Region> > >(1,(x10::lang::Region::makeRectangular(
                                                                                                           ((x10_int)0),
                                                                                                           Timer::
                                                                                                             FMGL(max_counters__get)())))),
                                              x10::lang::Place_methods::
                                                FMGL(FIRST_PLACE__get)());
    FMGL(d) = __var0__;
    FMGL(d__status) = x10aux::INITIALIZED;
}
void Timer::FMGL(d__init)() {
    if (x10aux::here == 0) {
        x10aux::status __var1__ = (x10aux::status)x10aux::atomic_ops::compareAndSet_32((volatile x10_int*)&FMGL(d__status), (x10_int)x10aux::UNINITIALIZED, (x10_int)x10aux::INITIALIZING);
        if (__var1__ != x10aux::UNINITIALIZED) goto WAIT;
        FMGL(d__do_init)();
        x10aux::StaticInitBroadcastDispatcher::broadcastStaticField(FMGL(d),
                                                                    FMGL(d__id));
        // Notify all waiting threads
        x10aux::StaticInitBroadcastDispatcher::notify();
    }
    WAIT:
    while (FMGL(d__status) != x10aux::INITIALIZED) x10aux::StaticInitBroadcastDispatcher::await();
}
static void* __init__2 X10_PRAGMA_UNUSED = x10aux::InitDispatcher::addInitializer(Timer::FMGL(d__init));

volatile x10aux::status Timer::FMGL(d__status);
// extract value from a buffer
x10aux::ref<x10::lang::Ref> Timer::FMGL(d__deserialize)(x10aux::deserialization_buffer &buf) {
    FMGL(d) = buf.read<x10aux::ref<x10::lang::Dist> >();
    Timer::FMGL(d__status) = x10aux::INITIALIZED;
    // Notify all waiting threads
    x10aux::StaticInitBroadcastDispatcher::notify();
    return x10aux::null;
}
const x10aux::serialization_id_t Timer::FMGL(d__id) =
  x10aux::StaticInitBroadcastDispatcher::addRoutine(Timer::FMGL(d__deserialize));


//#line 6 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10aux::ref<x10::lang::Rail<x10_double > >
  Timer::FMGL(start_time);
void Timer::FMGL(start_time__do_init)() {
    FMGL(start_time__status) = x10aux::INITIALIZING;
    _I_("Doing static initialisation for field: Timer.start_time");
    x10aux::ref<x10::lang::Rail<x10_double > >
      __var3__ =
      x10::lang::Rail<x10_double >::make(Timer::
                                           FMGL(max_counters__get)());
    FMGL(start_time) = __var3__;
    FMGL(start_time__status) = x10aux::INITIALIZED;
}
void Timer::FMGL(start_time__init)() {
    if (x10aux::here == 0) {
        x10aux::status __var4__ = (x10aux::status)x10aux::atomic_ops::compareAndSet_32((volatile x10_int*)&FMGL(start_time__status), (x10_int)x10aux::UNINITIALIZED, (x10_int)x10aux::INITIALIZING);
        if (__var4__ != x10aux::UNINITIALIZED) goto WAIT;
        FMGL(start_time__do_init)();
        x10aux::StaticInitBroadcastDispatcher::broadcastStaticField(FMGL(start_time),
                                                                    FMGL(start_time__id));
        // Notify all waiting threads
        x10aux::StaticInitBroadcastDispatcher::notify();
    }
    WAIT:
    while (FMGL(start_time__status) != x10aux::INITIALIZED) x10aux::StaticInitBroadcastDispatcher::await();
}
static void* __init__5 X10_PRAGMA_UNUSED = x10aux::InitDispatcher::addInitializer(Timer::FMGL(start_time__init));

volatile x10aux::status Timer::FMGL(start_time__status);
// extract value from a buffer
x10aux::ref<x10::lang::Ref> Timer::FMGL(start_time__deserialize)(x10aux::deserialization_buffer &buf) {
    FMGL(start_time) = buf.read<x10aux::ref<x10::lang::Rail<x10_double > > >();
    Timer::FMGL(start_time__status) = x10aux::INITIALIZED;
    // Notify all waiting threads
    x10aux::StaticInitBroadcastDispatcher::notify();
    return x10aux::null;
}
const x10aux::serialization_id_t Timer::FMGL(start_time__id) =
  x10aux::StaticInitBroadcastDispatcher::addRoutine(Timer::FMGL(start_time__deserialize));


//#line 7 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10aux::ref<x10::lang::Rail<x10_double > >
  Timer::FMGL(elapsed_time);
void Timer::FMGL(elapsed_time__do_init)() {
    FMGL(elapsed_time__status) = x10aux::INITIALIZING;
    _I_("Doing static initialisation for field: Timer.elapsed_time");
    x10aux::ref<x10::lang::Rail<x10_double > >
      __var6__ =
      x10::lang::Rail<x10_double >::make(Timer::
                                           FMGL(max_counters__get)());
    FMGL(elapsed_time) = __var6__;
    FMGL(elapsed_time__status) = x10aux::INITIALIZED;
}
void Timer::FMGL(elapsed_time__init)() {
    if (x10aux::here == 0) {
        x10aux::status __var7__ = (x10aux::status)x10aux::atomic_ops::compareAndSet_32((volatile x10_int*)&FMGL(elapsed_time__status), (x10_int)x10aux::UNINITIALIZED, (x10_int)x10aux::INITIALIZING);
        if (__var7__ != x10aux::UNINITIALIZED) goto WAIT;
        FMGL(elapsed_time__do_init)();
        x10aux::StaticInitBroadcastDispatcher::broadcastStaticField(FMGL(elapsed_time),
                                                                    FMGL(elapsed_time__id));
        // Notify all waiting threads
        x10aux::StaticInitBroadcastDispatcher::notify();
    }
    WAIT:
    while (FMGL(elapsed_time__status) != x10aux::INITIALIZED) x10aux::StaticInitBroadcastDispatcher::await();
}
static void* __init__8 X10_PRAGMA_UNUSED = x10aux::InitDispatcher::addInitializer(Timer::FMGL(elapsed_time__init));

volatile x10aux::status Timer::FMGL(elapsed_time__status);
// extract value from a buffer
x10aux::ref<x10::lang::Ref> Timer::FMGL(elapsed_time__deserialize)(x10aux::deserialization_buffer &buf) {
    FMGL(elapsed_time) = buf.read<x10aux::ref<x10::lang::Rail<x10_double > > >();
    Timer::FMGL(elapsed_time__status) = x10aux::INITIALIZED;
    // Notify all waiting threads
    x10aux::StaticInitBroadcastDispatcher::notify();
    return x10aux::null;
}
const x10aux::serialization_id_t Timer::FMGL(elapsed_time__id) =
  x10aux::StaticInitBroadcastDispatcher::addRoutine(Timer::FMGL(elapsed_time__deserialize));


//#line 8 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10aux::ref<x10::lang::Rail<x10_double > >
  Timer::FMGL(total_time);
void Timer::FMGL(total_time__do_init)() {
    FMGL(total_time__status) = x10aux::INITIALIZING;
    _I_("Doing static initialisation for field: Timer.total_time");
    x10aux::ref<x10::lang::Rail<x10_double > >
      __var9__ =
      x10::lang::Rail<x10_double >::make(Timer::
                                           FMGL(max_counters__get)());
    FMGL(total_time) = __var9__;
    FMGL(total_time__status) = x10aux::INITIALIZED;
}
void Timer::FMGL(total_time__init)() {
    if (x10aux::here == 0) {
        x10aux::status __var10__ = (x10aux::status)x10aux::atomic_ops::compareAndSet_32((volatile x10_int*)&FMGL(total_time__status), (x10_int)x10aux::UNINITIALIZED, (x10_int)x10aux::INITIALIZING);
        if (__var10__ != x10aux::UNINITIALIZED) goto WAIT;
        FMGL(total_time__do_init)();
        x10aux::StaticInitBroadcastDispatcher::broadcastStaticField(FMGL(total_time),
                                                                    FMGL(total_time__id));
        // Notify all waiting threads
        x10aux::StaticInitBroadcastDispatcher::notify();
    }
    WAIT:
    while (FMGL(total_time__status) != x10aux::INITIALIZED) x10aux::StaticInitBroadcastDispatcher::await();
}
static void* __init__11 X10_PRAGMA_UNUSED = x10aux::InitDispatcher::addInitializer(Timer::FMGL(total_time__init));

volatile x10aux::status Timer::FMGL(total_time__status);
// extract value from a buffer
x10aux::ref<x10::lang::Ref> Timer::FMGL(total_time__deserialize)(x10aux::deserialization_buffer &buf) {
    FMGL(total_time) = buf.read<x10aux::ref<x10::lang::Rail<x10_double > > >();
    Timer::FMGL(total_time__status) = x10aux::INITIALIZED;
    // Notify all waiting threads
    x10aux::StaticInitBroadcastDispatcher::notify();
    return x10aux::null;
}
const x10aux::serialization_id_t Timer::FMGL(total_time__id) =
  x10aux::StaticInitBroadcastDispatcher::addRoutine(Timer::FMGL(total_time__deserialize));


//#line 11 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void Timer::_constructor() {
    this->x10::lang::Ref::_constructor();
    
    //#line 12 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10_int i = ((x10_int)0);
    
    //#line 13 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    while (((i) < (Timer::FMGL(max_counters__get)())))
    {
        
        //#line 14 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        (*Timer::
            FMGL(start_time__get)())[i] = ((x10_double) (((x10_int)0)));
        
        //#line 15 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        (*Timer::
            FMGL(elapsed_time__get)())[i] = ((x10_double) (((x10_int)0)));
        
        //#line 16 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        (*Timer::
            FMGL(total_time__get)())[i] = ((x10_double) (((x10_int)0)));
        
        //#line 17 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        i +=
          ((x10_int)1);
    }
    
}x10aux::ref<Timer> Timer::_make() {
    x10aux::ref<Timer> this_ = new (x10aux::alloc<Timer>()) Timer();
    this_->_constructor();
    return this_;
}



//#line 21 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void Timer::start(x10_int n) {
    
    //#line 22 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    (*Timer::FMGL(start_time__get)())[n] = ((x10_double) (x10::lang::System::currentTimeMillis()));
}

//#line 25 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void Timer::stop(x10_int n) {
    
    //#line 26 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    (*Timer::FMGL(elapsed_time__get)())[n] = ((((x10_double) (x10::lang::System::currentTimeMillis()))) - ((*Timer::
                                                                                                               FMGL(start_time__get)())[n]));
    
    //#line 27 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    (__extension__ ({
        x10aux::ref<x10::lang::Rail<x10_double > > x =
          Timer::
            FMGL(elapsed_time__get)();
        x10_int y0 =
          n;
        x10_double z =
          ((x10_double) (((x10_int)1000)));
        (*x)[y0] = (((*x)[y0]) / (z));
    }))
    ;
    
    //#line 28 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    (__extension__ ({
        x10aux::ref<x10::lang::Rail<x10_double > > x =
          Timer::
            FMGL(total_time__get)();
        x10_int y0 =
          n;
        x10_double z =
          (*Timer::
              FMGL(elapsed_time__get)())[n];
        (*x)[y0] = (((*x)[y0]) + (z));
    }))
    ;
}

//#line 31 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10_double Timer::readTimer(x10_int n) {
    
    //#line 32 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    return (*Timer::FMGL(total_time__get)())[n];
    
}

//#line 35 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void Timer::resetTimer(x10_int n) {
    
    //#line 36 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    (*Timer::FMGL(total_time__get)())[n] = ((x10_double) (((x10_int)0)));
    
    //#line 37 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    (*Timer::FMGL(start_time__get)())[n] = ((x10_double) (((x10_int)0)));
    
    //#line 38 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    (*Timer::FMGL(elapsed_time__get)())[n] = ((x10_double) (((x10_int)0)));
}

//#line 41 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void Timer::resetAllTimers() {
    
    //#line 42 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10_int i = ((x10_int)0);
    
    //#line 43 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    while (((i) < (Timer::FMGL(max_counters__get)())))
    {
        
        //#line 44 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        x10aux::nullCheck(((x10aux::ref<Timer>)this))->resetTimer(
          i);
        
        //#line 45 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        i +=
          ((x10_int)1);
    }
    
}
const x10aux::serialization_id_t Timer::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(Timer::_deserializer<x10::lang::Ref>);

void Timer::_serialize_body(x10aux::serialization_buffer& buf, x10aux::addr_map& m) {
    x10::lang::Ref::_serialize_body(buf, m);
    
}

void Timer::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::lang::Ref::_deserialize_body(buf);
    
}

x10aux::RuntimeType Timer::rtt;
void Timer::_initRTT() {
    rtt.canonical = &rtt;
    const x10aux::RuntimeType* parents[1] = { x10aux::getRTT<x10::lang::Ref>()};
    rtt.init(&rtt, "Timer", 1, parents, 0, NULL, NULL);
}

extern "C" { const char* LNMAP__Timer_cc = "N{\"Timer.cc\"} F{0:\"/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translatedbenchs/hand/mapreduce/V2.0/MapReduce.x10\",1:\"Timer\",2:\"this\",3:\"\",4:\"_constructor\",5:\"void\",6:\"start\",7:\"x10.lang.Void\",8:\"x10.lang.Int\",9:\"x10_int\",10:\"stop\",11:\"readTimer\",12:\"x10.lang.Double\",13:\"x10_double\",14:\"resetTimer\",15:\"resetAllTimers\",} L{274->0:36,204->0:16,200->0:15,277->0:37,196->0:14,281->0:39,280->0:38,287->0:42,192->0:13,13->0:3,284->0:41,17->0:4,221->0:21,263->0:31,260->0:29,144->0:8,266->0:32,208->0:17,271->0:35,210->0:18,268->0:33,103->0:7,235->0:27,231->0:26,228->0:25,225->0:23,224->0:22,290->0:43,185->0:11,294->0:44,248->0:28,189->0:12,298->0:45,300->0:46,62->0:6,302->0:47,} M{5 1.6(9)->7 1.6(8);5 1.4()->3 1.2();5 1.15()->7 1.15();5 1.10(9)->7 1.10(8);13 1.11(9)->12 1.11(8);5 1.14(9)->7 1.14(8);}"; }
