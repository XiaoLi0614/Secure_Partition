#ifndef __MR_H
#define __MR_H

#include <x10rt17.h>

#define X10_LANG_OBJECT_H_NODEPS
#include <x10/lang/Object.h>
#undef X10_LANG_OBJECT_H_NODEPS
#define X10_LANG_INT_STRUCT_H_NODEPS
#include <x10/lang/Int.struct_h>
#undef X10_LANG_INT_STRUCT_H_NODEPS
namespace x10 { namespace lang { 
class Region;
} } 
namespace x10 { namespace lang { 
class Dist;
} } 
namespace x10 { namespace lang { 
template<class FMGL(T)> class Array;
} } 
namespace x10 { namespace lang { 
class Int;
} } 
#include <x10/lang/Int.struct_h>
namespace x10 { namespace lang { 
template<class FMGL(T)> class Array;
} } 
namespace x10 { namespace lang { 
template<class FMGL(Z1), class FMGL(U)> class Fun_0_1;
} } 
namespace x10 { namespace lang { 
class Point;
} } 
namespace x10 { namespace io { 
class Console;
} } 
namespace x10 { namespace runtime { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class VoidFun_0_0;
} } 
namespace x10 { namespace lang { 
class Throwable;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
#include <x10/lang/Place.struct_h>
namespace x10 { namespace lang { 
template<class FMGL(Z1), class FMGL(U)> class Fun_0_1;
} } 
namespace x10 { namespace lang { 
class ClassCastException;
} } 
class MR : public x10::lang::Ref   {
    public:
    RTT_H_DECLS_CLASS
    
    void _instance_init();
    
    static x10aux::ref<x10::lang::Region> FMGL(r);
    
    static void FMGL(r__do_init)();
    static void FMGL(r__init)();
    static volatile x10aux::status FMGL(r__status);
    static x10aux::ref<x10::lang::Region> FMGL(r__get)() {
        if (FMGL(r__status) != x10aux::INITIALIZED) {
            FMGL(r__init)();
        }
        return MR::FMGL(r);
    }
    static x10aux::ref<x10::lang::Ref> FMGL(r__deserialize)(x10aux::deserialization_buffer &buf);
    static const x10aux::serialization_id_t FMGL(r__id);
    
    static x10aux::ref<x10::lang::Dist> FMGL(d);
    
    static void FMGL(d__do_init)();
    static void FMGL(d__init)();
    static volatile x10aux::status FMGL(d__status);
    static x10aux::ref<x10::lang::Dist> FMGL(d__get)() {
        if (FMGL(d__status) != x10aux::INITIALIZED) {
            FMGL(d__init)();
        }
        return MR::FMGL(d);
    }
    static x10aux::ref<x10::lang::Ref> FMGL(d__deserialize)(x10aux::deserialization_buffer &buf);
    static const x10aux::serialization_id_t FMGL(d__id);
    
    x10aux::ref<x10::lang::Array<x10_int> > FMGL(a);
    
    x10_int FMGL(total);
    
    void _constructor();
    
    static x10aux::ref<MR> _make();
    
    virtual void run();
    virtual void map();
    virtual x10_int f(x10_int x);
    virtual void reduce();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf, x10aux::addr_map& m);
    
    public: template<class __T> static x10aux::ref<__T> _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};
#endif // MR_H

class MR;

#ifndef MR_H_NODEPS
#define MR_H_NODEPS
#include <x10/lang/Object.h>
#include <x10/lang/Region.h>
#include <x10/lang/Dist.h>
#include <x10/lang/Array.h>
#include <x10/lang/Int.h>
#include <x10/lang/Array.h>
#include <x10/lang/Fun_0_1.h>
#include <x10/lang/Point.h>
#include <x10/io/Console.h>
#include <x10/runtime/Runtime.h>
#include <x10/lang/VoidFun_0_0.h>
#include <x10/lang/Throwable.h>
#include <x10/lang/Place.h>
#include <x10/lang/Fun_0_1.h>
#include <x10/lang/ClassCastException.h>
#ifndef MR_H_GENERICS
#define MR_H_GENERICS
template<class __T> x10aux::ref<__T> MR::_deserializer(x10aux::deserialization_buffer& buf) {
    x10aux::ref<MR> this_ = new (x10aux::alloc_remote<MR>()) MR();
    this_->_deserialize_body(buf);
    return this_;
}

#endif // MR_H_GENERICS
#endif // __MR_H_NODEPS
