#ifndef __MAPREDUCE_H
#define __MAPREDUCE_H

#include <x10rt17.h>

#define X10_LANG_OBJECT_H_NODEPS
#include <x10/lang/Object.h>
#undef X10_LANG_OBJECT_H_NODEPS
namespace x10 { namespace lang { 
template<class FMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
class String;
} } 
class Timer;
namespace x10 { namespace lang { 
class Int;
} } 
#include <x10/lang/Int.struct_h>
class MR;
namespace x10 { namespace io { 
class Console;
} } 
class MapReduce : public x10::lang::Ref   {
    public:
    RTT_H_DECLS_CLASS
    
    void _instance_init();
    
    static void main(x10aux::ref<x10::lang::Rail<x10aux::ref<x10::lang::String> > > id1);
    void _constructor();
    
    static x10aux::ref<MapReduce> _make();
    
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf, x10aux::addr_map& m);
    
    public: template<class __T> static x10aux::ref<__T> _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};
#endif // MAPREDUCE_H

class MapReduce;

#ifndef MAPREDUCE_H_NODEPS
#define MAPREDUCE_H_NODEPS
#include <x10/lang/Object.h>
#include <x10/lang/Rail.h>
#include <x10/lang/String.h>
#include <Timer.h>
#include <x10/lang/Int.h>
#include <MR.h>
#include <x10/io/Console.h>
#ifndef MAPREDUCE_H_GENERICS
#define MAPREDUCE_H_GENERICS
template<class __T> x10aux::ref<__T> MapReduce::_deserializer(x10aux::deserialization_buffer& buf) {
    x10aux::ref<MapReduce> this_ = new (x10aux::alloc_remote<MapReduce>()) MapReduce();
    this_->_deserialize_body(buf);
    return this_;
}

#endif // MAPREDUCE_H_GENERICS
#endif // __MAPREDUCE_H_NODEPS
