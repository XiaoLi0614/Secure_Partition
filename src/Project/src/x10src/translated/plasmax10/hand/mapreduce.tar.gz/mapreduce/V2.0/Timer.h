#ifndef __TIMER_H
#define __TIMER_H

#include <x10rt17.h>

#define X10_LANG_OBJECT_H_NODEPS
#include <x10/lang/Object.h>
#undef X10_LANG_OBJECT_H_NODEPS
namespace x10 { namespace lang { 
class Int;
} } 
#include <x10/lang/Int.struct_h>
namespace x10 { namespace lang { 
class Dist;
} } 
namespace x10 { namespace lang { 
class Region;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
#include <x10/lang/Place.struct_h>
namespace x10 { namespace lang { 
template<class FMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
class Double;
} } 
#include <x10/lang/Double.struct_h>
namespace x10 { namespace runtime { 
class Runtime;
} } 
namespace x10 { namespace lang { 
template<class FMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
class System;
} } 
namespace x10 { namespace lang { 
template<class FMGL(Z1), class FMGL(Z2), class FMGL(Z3), class FMGL(U)> class Fun_0_3;
} } 
class Timer : public x10::lang::Ref   {
    public:
    RTT_H_DECLS_CLASS
    
    void _instance_init();
    
    static x10_int FMGL(max_counters);
    
    static x10_int FMGL(max_counters__get)() {
        return Timer::FMGL(max_counters);
    }
    static x10aux::ref<x10::lang::Dist> FMGL(d);
    
    static void FMGL(d__do_init)();
    static void FMGL(d__init)();
    static volatile x10aux::status FMGL(d__status);
    static x10aux::ref<x10::lang::Dist> FMGL(d__get)() {
        if (FMGL(d__status) != x10aux::INITIALIZED) {
            FMGL(d__init)();
        }
        return Timer::FMGL(d);
    }
    static x10aux::ref<x10::lang::Ref> FMGL(d__deserialize)(x10aux::deserialization_buffer &buf);
    static const x10aux::serialization_id_t FMGL(d__id);
    
    static x10aux::ref<x10::lang::Rail<x10_double > > FMGL(start_time);
    
    static void FMGL(start_time__do_init)();
    static void FMGL(start_time__init)();
    static volatile x10aux::status FMGL(start_time__status);
    static x10aux::ref<x10::lang::Rail<x10_double > > FMGL(start_time__get)() {
        if (FMGL(start_time__status) != x10aux::INITIALIZED) {
            FMGL(start_time__init)();
        }
        return Timer::FMGL(start_time);
    }
    static x10aux::ref<x10::lang::Ref> FMGL(start_time__deserialize)(x10aux::deserialization_buffer &buf);
    static const x10aux::serialization_id_t FMGL(start_time__id);
    
    static x10aux::ref<x10::lang::Rail<x10_double > > FMGL(elapsed_time);
    
    static void FMGL(elapsed_time__do_init)();
    static void FMGL(elapsed_time__init)();
    static volatile x10aux::status FMGL(elapsed_time__status);
    static x10aux::ref<x10::lang::Rail<x10_double > > FMGL(elapsed_time__get)() {
        if (FMGL(elapsed_time__status) != x10aux::INITIALIZED) {
            FMGL(elapsed_time__init)();
        }
        return Timer::FMGL(elapsed_time);
    }
    static x10aux::ref<x10::lang::Ref> FMGL(elapsed_time__deserialize)(x10aux::deserialization_buffer &buf);
    static const x10aux::serialization_id_t FMGL(elapsed_time__id);
    
    static x10aux::ref<x10::lang::Rail<x10_double > > FMGL(total_time);
    
    static void FMGL(total_time__do_init)();
    static void FMGL(total_time__init)();
    static volatile x10aux::status FMGL(total_time__status);
    static x10aux::ref<x10::lang::Rail<x10_double > > FMGL(total_time__get)() {
        if (FMGL(total_time__status) != x10aux::INITIALIZED) {
            FMGL(total_time__init)();
        }
        return Timer::FMGL(total_time);
    }
    static x10aux::ref<x10::lang::Ref> FMGL(total_time__deserialize)(x10aux::deserialization_buffer &buf);
    static const x10aux::serialization_id_t FMGL(total_time__id);
    
    void _constructor();
    
    static x10aux::ref<Timer> _make();
    
    virtual void start(x10_int n);
    virtual void stop(x10_int n);
    virtual x10_double readTimer(x10_int n);
    virtual void resetTimer(x10_int n);
    virtual void resetAllTimers();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf, x10aux::addr_map& m);
    
    public: template<class __T> static x10aux::ref<__T> _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};
#endif // TIMER_H

class Timer;

#ifndef TIMER_H_NODEPS
#define TIMER_H_NODEPS
#include <x10/lang/Object.h>
#include <x10/lang/Int.h>
#include <x10/lang/Dist.h>
#include <x10/lang/Region.h>
#include <x10/lang/Place.h>
#include <x10/lang/Rail.h>
#include <x10/lang/Double.h>
#include <x10/runtime/Runtime.h>
#include <x10/lang/Rail.h>
#include <x10/lang/System.h>
#include <x10/lang/Fun_0_3.h>
#ifndef TIMER_H_GENERICS
#define TIMER_H_GENERICS
template<class __T> x10aux::ref<__T> Timer::_deserializer(x10aux::deserialization_buffer& buf) {
    x10aux::ref<Timer> this_ = new (x10aux::alloc_remote<Timer>()) Timer();
    this_->_deserialize_body(buf);
    return this_;
}

#endif // TIMER_H_GENERICS
#endif // __TIMER_H_NODEPS
