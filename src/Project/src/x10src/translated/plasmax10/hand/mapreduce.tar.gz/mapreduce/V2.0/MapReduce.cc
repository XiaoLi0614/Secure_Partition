#include <MapReduce.h>


#include "MapReduce.inc"

void MapReduce::_instance_init() {
    _I_("Doing initialisation for class: MapReduce");
    
}


//#line 113 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
#include <x10/runtime/Runtime.h>
#include <x10aux/bootstrap.h>
extern "C" { int main(int ac, char **av) { return x10aux::template_main<x10::runtime::Runtime,MapReduce>(ac,av); } }

void MapReduce::main(x10aux::ref<x10::lang::Rail<x10aux::ref<x10::lang::String> > > id1) {
    
    //#line 114 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::ref<Timer> tmr = Timer::_make();
    
    //#line 115 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10_int count = ((x10_int)0);
    
    //#line 116 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::nullCheck(tmr)->start(count);
    
    //#line 117 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::nullCheck((MR::_make()))->run();
    
    //#line 118 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::nullCheck(tmr)->stop(count);
    
    //#line 119 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::nullCheck(x10::io::Console::FMGL(OUT__get)())->x10::io::Printer::println(
      x10aux::class_cast_unchecked<x10aux::ref<x10::lang::Ref> >(x10::lang::String::Lit("Wall-clock time for mapreduce: ") +
      x10aux::safe_to_string(x10aux::nullCheck(tmr)->readTimer(
                               count)) +
      x10::lang::String::Lit(" secs")));
}

//#line 112 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void MapReduce::_constructor() {
    this->x10::lang::Ref::_constructor();
    
}x10aux::ref<MapReduce> MapReduce::_make() {
    x10aux::ref<MapReduce> this_ = new (x10aux::alloc<MapReduce>()) MapReduce();
    this_->_constructor();
    return this_;
}


const x10aux::serialization_id_t MapReduce::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(MapReduce::_deserializer<x10::lang::Ref>);

void MapReduce::_serialize_body(x10aux::serialization_buffer& buf, x10aux::addr_map& m) {
    x10::lang::Ref::_serialize_body(buf, m);
    
}

void MapReduce::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::lang::Ref::_deserialize_body(buf);
    
}

x10aux::RuntimeType MapReduce::rtt;
void MapReduce::_initRTT() {
    rtt.canonical = &rtt;
    const x10aux::RuntimeType* parents[1] = { x10aux::getRTT<x10::lang::Ref>()};
    rtt.init(&rtt, "MapReduce", 1, parents, 0, NULL, NULL);
}

extern "C" { const char* LNMAP__MapReduce_cc = "N{\"MapReduce.cc\"} F{0:\"/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translatedbenchs/hand/mapreduce/V2.0/MapReduce.x10\",1:\"MapReduce\",2:\"main\",3:\"x10.lang.Void\",4:\"x10.lang.Rail[x10.lang.String]\",5:\"void\",6:\"x10aux::ref<x10::lang::Rail<x10aux::ref<x10::lang::String> > >\",7:\"this\",8:\"\",9:\"_constructor\",} L{35->0:119,32->0:118,20->0:114,23->0:115,43->0:112,40->0:120,26->0:116,29->0:117,13->0:113,} M{5 1.9()->8 1.7();5 1.2(6)->3 1.2(4);}"; }
