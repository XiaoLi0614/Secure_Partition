#include <MR.h>


#include "MR.inc"

void MR::_instance_init() {
    _I_("Doing initialisation for class: MR");
    
}


//#line 54 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10aux::ref<x10::lang::Region> MR::FMGL(r);
void MR::FMGL(r__do_init)() {
    FMGL(r__status) = x10aux::INITIALIZING;
    _I_("Doing static initialisation for field: MR.r");
    x10aux::ref<x10::lang::Region> __var17__ = x10::lang::Region::makeRectangular(
                                                 ((x10_int)0),
                                                 ((x10_int)300));
    FMGL(r) = __var17__;
    FMGL(r__status) = x10aux::INITIALIZED;
}
void MR::FMGL(r__init)() {
    if (x10aux::here == 0) {
        x10aux::status __var18__ = (x10aux::status)x10aux::atomic_ops::compareAndSet_32((volatile x10_int*)&FMGL(r__status), (x10_int)x10aux::UNINITIALIZED, (x10_int)x10aux::INITIALIZING);
        if (__var18__ != x10aux::UNINITIALIZED) goto WAIT;
        FMGL(r__do_init)();
        x10aux::StaticInitBroadcastDispatcher::broadcastStaticField(FMGL(r),
                                                                    FMGL(r__id));
        // Notify all waiting threads
        x10aux::StaticInitBroadcastDispatcher::notify();
    }
    WAIT:
    while (FMGL(r__status) != x10aux::INITIALIZED) x10aux::StaticInitBroadcastDispatcher::await();
}
static void* __init__19 X10_PRAGMA_UNUSED = x10aux::InitDispatcher::addInitializer(MR::FMGL(r__init));

volatile x10aux::status MR::FMGL(r__status);
// extract value from a buffer
x10aux::ref<x10::lang::Ref> MR::FMGL(r__deserialize)(x10aux::deserialization_buffer &buf) {
    FMGL(r) = buf.read<x10aux::ref<x10::lang::Region> >();
    MR::FMGL(r__status) = x10aux::INITIALIZED;
    // Notify all waiting threads
    x10aux::StaticInitBroadcastDispatcher::notify();
    return x10aux::null;
}
const x10aux::serialization_id_t MR::FMGL(r__id) = x10aux::StaticInitBroadcastDispatcher::addRoutine(MR::FMGL(r__deserialize));


//#line 55 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10aux::ref<x10::lang::Dist> MR::FMGL(d);
void MR::FMGL(d__do_init)() {
    FMGL(d__status) = x10aux::INITIALIZING;
    _I_("Doing static initialisation for field: MR.d");
    x10aux::ref<x10::lang::Dist> __var20__ = x10::lang::Dist::makeBlock(
                                               MR::
                                                 FMGL(r__get)());
    FMGL(d) = __var20__;
    FMGL(d__status) = x10aux::INITIALIZED;
}
void MR::FMGL(d__init)() {
    if (x10aux::here == 0) {
        x10aux::status __var21__ = (x10aux::status)x10aux::atomic_ops::compareAndSet_32((volatile x10_int*)&FMGL(d__status), (x10_int)x10aux::UNINITIALIZED, (x10_int)x10aux::INITIALIZING);
        if (__var21__ != x10aux::UNINITIALIZED) goto WAIT;
        FMGL(d__do_init)();
        x10aux::StaticInitBroadcastDispatcher::broadcastStaticField(FMGL(d),
                                                                    FMGL(d__id));
        // Notify all waiting threads
        x10aux::StaticInitBroadcastDispatcher::notify();
    }
    WAIT:
    while (FMGL(d__status) != x10aux::INITIALIZED) x10aux::StaticInitBroadcastDispatcher::await();
}
static void* __init__22 X10_PRAGMA_UNUSED = x10aux::InitDispatcher::addInitializer(MR::FMGL(d__init));

volatile x10aux::status MR::FMGL(d__status);
// extract value from a buffer
x10aux::ref<x10::lang::Ref> MR::FMGL(d__deserialize)(x10aux::deserialization_buffer &buf) {
    FMGL(d) = buf.read<x10aux::ref<x10::lang::Dist> >();
    MR::FMGL(d__status) = x10aux::INITIALIZED;
    // Notify all waiting threads
    x10aux::StaticInitBroadcastDispatcher::notify();
    return x10aux::null;
}
const x10aux::serialization_id_t MR::FMGL(d__id) = x10aux::StaticInitBroadcastDispatcher::addRoutine(MR::FMGL(d__deserialize));


//#line 57 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"

//#line 58 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"

//#line 60 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void MR::_constructor() {
    this->x10::lang::Ref::_constructor();
    
    //#line 61 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    ((x10aux::ref<MR>)this)->FMGL(a) = x10::lang::Array<void>::makeVar<x10_int >(
                                         MR::
                                           FMGL(d__get)(),
                                         x10aux::class_cast_unchecked<x10aux::ref<x10::lang::Fun_0_1<x10aux::ref<x10::lang::Point>, x10_int> > >(x10aux::ref<x10::lang::Fun_0_1<x10aux::ref<x10::lang::Point>, x10_int> >(x10aux::ref<MR__closure__0>(new (x10aux::alloc<x10::lang::Fun_0_1<x10aux::ref<x10::lang::Point>, x10_int> >(sizeof(MR__closure__0)))MR__closure__0()))));
    
    //#line 62 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    ((x10aux::ref<MR>)this)->FMGL(total) = ((x10_int)0);
    
}x10aux::ref<MR> MR::_make() {
    x10aux::ref<MR> this_ = new (x10aux::alloc<MR>()) MR();
    this_->_constructor();
    return this_;
}



//#line 65 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void MR::run() {
    
    //#line 66 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::nullCheck(((x10aux::ref<MR>)this))->map();
    
    //#line 66 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::nullCheck(((x10aux::ref<MR>)this))->reduce();
    
    //#line 66 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::nullCheck(x10::io::Console::FMGL(OUT__get)())->x10::io::Printer::println(
      ((x10aux::ref<MR>)this)->
        FMGL(total));
}

//#line 69 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void MR::map() {
    
    //#line 70 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::ref<x10::lang::Array<x10_int> > b = ((x10aux::ref<MR>)this)->
                                                  FMGL(a);
    
    //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    try {
    try {
        
        //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        x10::runtime::Runtime::startFinish();
        {
            {
                
                //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
                x10aux::ref<x10::lang::Dist> __desugarer__var__0__ =
                  x10aux::nullCheck(b)->
                    FMGL(dist);
                
                //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
                {
                    x10aux::ref<x10::lang::Object> __ip = (x10aux::nullCheck(__desugarer__var__0__))->iterator();
                    x10::lang::Iterator<x10aux::ref<x10::lang::Point> >::itable<x10::lang::Object> *__ip_itable = x10aux::findITable<x10::lang::Iterator<x10aux::ref<x10::lang::Point> > >(__ip->_getITables());
                    for (; (((x10::lang::Object*)(__ip.operator->()))->*(__ip_itable->hasNext))();
                           ) {
                        x10aux::ref<x10::lang::Point> p;
                        p = (((x10::lang::Object*)(__ip.operator->()))->*(__ip_itable->next))();
                        {
                            
                            //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
                            x10::runtime::Runtime::runAsync(
                              x10aux::nullCheck(__desugarer__var__0__)->apply(
                                p),
                              x10aux::class_cast_unchecked<x10aux::ref<x10::lang::VoidFun_0_0> >(x10aux::ref<x10::lang::VoidFun_0_0>(x10aux::ref<MR__closure__1>(new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(MR__closure__1)))MR__closure__1(b, this, p)))));
                        }
                    }
                }
                
            }
        }
    }
    catch (x10aux::__ref& __ref__25) {
        x10aux::ref<x10::lang::Throwable>& __exc__ref__25 = (x10aux::ref<x10::lang::Throwable>&)__ref__25;
        
        //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        if (x10aux::instanceof<x10aux::ref<x10::lang::Throwable> >(__exc__ref__25)) {
            x10aux::ref<x10::lang::Throwable> __desugarer__var__1__ =
              static_cast<x10aux::ref<x10::lang::Throwable> >(__exc__ref__25);
            {
                
                //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
                x10::runtime::Runtime::pushException(
                  __desugarer__var__1__);
            }
        } else
        throw;
    }
    } catch (...) {
        {
            
            //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
            x10::runtime::Runtime::stopFinish();
        }
        throw;
    }
    {
        
        //#line 71 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        x10::runtime::Runtime::stopFinish();
    }
}

//#line 77 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
x10_int MR::f(x10_int x) {
    
    //#line 77 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    return ((x) * (x));
    
}

//#line 79 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
void MR::reduce() {
    
    //#line 80 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10::lang::Place h = x10::runtime::Runtime::here();
    
    //#line 81 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::ref<x10::lang::Region> reg = x10aux::nullCheck(((x10aux::ref<MR>)this)->
                                                             FMGL(a))->x10::lang::Array<x10_int>::region();
    
    //#line 82 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::ref<x10::lang::Dist> dis = x10::lang::Dist::makeConstant(
                                         reg,
                                         x10::runtime::Runtime::here());
    
    //#line 83 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    x10aux::ref<x10::lang::Array<x10_int> > result =
      x10::lang::Array<void>::makeVar<x10_int >(
        dis);
    
    //#line 86 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    try {
    try {
        
        //#line 86 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        x10::runtime::Runtime::startFinish();
        {
            
            //#line 87 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
            {
                x10aux::ref<x10::lang::Object> __ip = (x10aux::nullCheck(((x10aux::ref<MR>)this)->
                                                                           FMGL(a)))->iterator();
                x10::lang::Iterator<x10aux::ref<x10::lang::Point> >::itable<x10::lang::Object> *__ip_itable = x10aux::findITable<x10::lang::Iterator<x10aux::ref<x10::lang::Point> > >(__ip->_getITables());
                for (; (((x10::lang::Object*)(__ip.operator->()))->*(__ip_itable->hasNext))();
                       ) {
                    x10aux::ref<x10::lang::Point> p;
                    p = (((x10::lang::Object*)(__ip.operator->()))->*(__ip_itable->next))();
                    {
                        
                        //#line 87 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
                        x10::runtime::Runtime::runAsync(
                          x10::runtime::Runtime::here(),
                          x10aux::class_cast_unchecked<x10aux::ref<x10::lang::VoidFun_0_0> >(x10aux::ref<x10::lang::VoidFun_0_0>(x10aux::ref<MR__closure__2>(new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(MR__closure__2)))MR__closure__2(this, p, h, result)))));
                    }
                }
            }
            
        }
    }
    catch (x10aux::__ref& __ref__30) {
        x10aux::ref<x10::lang::Throwable>& __exc__ref__30 = (x10aux::ref<x10::lang::Throwable>&)__ref__30;
        
        //#line 86 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        if (x10aux::instanceof<x10aux::ref<x10::lang::Throwable> >(__exc__ref__30)) {
            x10aux::ref<x10::lang::Throwable> __desugarer__var__3__ =
              static_cast<x10aux::ref<x10::lang::Throwable> >(__exc__ref__30);
            {
                
                //#line 86 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
                x10::runtime::Runtime::pushException(
                  __desugarer__var__3__);
            }
        } else
        throw;
    }
    } catch (...) {
        {
            
            //#line 86 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
            x10::runtime::Runtime::stopFinish();
        }
        throw;
    }
    {
        
        //#line 86 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        x10::runtime::Runtime::stopFinish();
    }
    
    //#line 99 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
    try {
    try {
        
        //#line 99 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        x10::runtime::Runtime::startFinish();
        {
            
            //#line 100 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
            {
                x10aux::ref<x10::lang::Object> __ip = (x10aux::nullCheck(result))->iterator();
                x10::lang::Iterator<x10aux::ref<x10::lang::Point> >::itable<x10::lang::Object> *__ip_itable = x10aux::findITable<x10::lang::Iterator<x10aux::ref<x10::lang::Point> > >(__ip->_getITables());
                for (; (((x10::lang::Object*)(__ip.operator->()))->*(__ip_itable->hasNext))();
                       ) {
                    x10aux::ref<x10::lang::Point> p;
                    p = (((x10::lang::Object*)(__ip.operator->()))->*(__ip_itable->next))();
                    {
                        
                        //#line 100 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
                        x10::runtime::Runtime::runAsync(
                          x10::runtime::Runtime::here(),
                          x10aux::class_cast_unchecked<x10aux::ref<x10::lang::VoidFun_0_0> >(x10aux::ref<x10::lang::VoidFun_0_0>(x10aux::ref<MR__closure__5>(new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(MR__closure__5)))MR__closure__5(this, result, p)))));
                    }
                }
            }
            
        }
    }
    catch (x10aux::__ref& __ref__31) {
        x10aux::ref<x10::lang::Throwable>& __exc__ref__31 = (x10aux::ref<x10::lang::Throwable>&)__ref__31;
        
        //#line 99 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        if (x10aux::instanceof<x10aux::ref<x10::lang::Throwable> >(__exc__ref__31)) {
            x10aux::ref<x10::lang::Throwable> __desugarer__var__4__ =
              static_cast<x10aux::ref<x10::lang::Throwable> >(__exc__ref__31);
            {
                
                //#line 99 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
                x10::runtime::Runtime::pushException(
                  __desugarer__var__4__);
            }
        } else
        throw;
    }
    } catch (...) {
        {
            
            //#line 99 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
            x10::runtime::Runtime::stopFinish();
        }
        throw;
    }
    {
        
        //#line 99 "/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translated/hand/mapreduce/V2.0/MapReduce.x10"
        x10::runtime::Runtime::stopFinish();
    }
}
const x10aux::serialization_id_t MR::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(MR::_deserializer<x10::lang::Ref>);

void MR::_serialize_body(x10aux::serialization_buffer& buf, x10aux::addr_map& m) {
    x10::lang::Ref::_serialize_body(buf, m);
    
}

void MR::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::lang::Ref::_deserialize_body(buf);
    
}

x10aux::RuntimeType MR::rtt;
void MR::_initRTT() {
    rtt.canonical = &rtt;
    const x10aux::RuntimeType* parents[1] = { x10aux::getRTT<x10::lang::Ref>()};
    rtt.init(&rtt, "MR", 1, parents, 0, NULL, NULL);
}

extern "C" { const char* LNMAP__MR_cc = "N{\"MR.cc\"} F{0:\"/media/MOHSENHD/1.Works/3.Research/0.Research/2.Plasma/2.Project/Project/src/x10/translatedbenchs/hand/mapreduce/V2.0/MapReduce.x10\",1:\"MR\",2:\"this\",3:\"\",4:\"_constructor\",5:\"void\",6:\"run\",7:\"x10.lang.Void\",8:\"map\",9:\"f\",10:\"x10.lang.Int\",11:\"x10_int\",12:\"reduce\",} L{136->0:71,279->0:86,140->0:71,129->0:69,280->0:98,287->0:98,286->0:86,132->0:70,13->0:54,258->0:98,257->0:98,263->0:86,145->0:71,271->0:98,151->0:71,269->0:86,170->0:74,169->0:74,168->0:74,175->0:71,308->0:100,311->0:106,315->0:107,160->0:71,316->0:107,164->0:74,51->0:55,290->0:99,191->0:71,294->0:99,299->0:100,183->0:74,181->0:71,206->0:77,338->0:107,200->0:75,337->0:99,203->0:77,199->0:74,198->0:71,346->0:108,192->0:74,345->0:107,344->0:99,327->0:99,221->0:82,217->0:81,321->0:99,93->0:60,214->0:80,89->0:57,208->0:77,91->0:58,329->0:107,211->0:79,103->0:62,235->0:86,97->0:61,231->0:86,226->0:83,117->0:66,253->0:97,250->0:87,114->0:65,126->0:67,123->0:66,240->0:87,120->0:66,} M{11 1.9(11)->10 1.9(10);5 1.8()->7 1.8();5 1.4()->3 1.2();5 1.12()->7 1.12();5 1.6()->7 1.6();}"; }
